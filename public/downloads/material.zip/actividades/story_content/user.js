function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6OsSSxm5jMs":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

